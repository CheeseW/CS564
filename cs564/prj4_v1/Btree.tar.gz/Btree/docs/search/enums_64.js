var searchData=
[
  ['datatype',['Datatype',['../namespacebadgerdb.html#a9dc9c8fe64ff894720886ba4b9f81f4b',1,'badgerdb']]]
];
